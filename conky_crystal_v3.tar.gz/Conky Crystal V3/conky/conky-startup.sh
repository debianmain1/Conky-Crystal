#!/bin/bash

killall conky

conky -q -c ~/.conky/conkyrc_crystal ;

exit 0
